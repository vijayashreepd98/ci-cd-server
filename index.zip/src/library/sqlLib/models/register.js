// const { mongoose, Schema, model } = require("mongoose");
// const connectDb = require("../../../dbConnection/mongoConnect");
// connectDb();

// const registerModel = new Schema({
//     user_name: {
//         type: String,
//         required: true,
//     },
//     password: {
//         type: String,
//         required: true
//     },
//     created_at: {
//         type: Date,

//     },
//     status: {
//         type: Number,
//         default: 1
//     }
// });

// const register = model("register", registerModel);

// module.exports = register;